itp_shield_no_parry = 0x0000000000004000 # left handed item without shield functionality
itp_offset_mortschlag = 0x1000000000000000 # offsets melee weapon to mortschlag grip
itp_offset_flip = 0x4000000000000000 # flips melee weapon model 180 degrees on y-axis
