﻿To enhance the module system, add the contents of the _addon files to your original module files.
Some files (header_operations_addon.py) require that you append their contents at the end of the original file.

If you're not a modder you can safely ignore this folder and all the files in it.
