sokf_weapon_knock_back_collision     = 0x0000000010000000 # weapon knock back by hit destructible prop
